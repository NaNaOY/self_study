package day1;

import java.util.Scanner;

public class ex2_4 {
	public static void main(String[] args){
		double[]p = null;
		int n=0;
		Array.printArray(p);
	}
}
class Array{
	public static double[] getArray(int n){
		double[] num=new double[n];
		Scanner input=new Scanner(System.in);
		for(int i=0;i<n;i++){
			num[i]=input.nextDouble();
		}
		return num;
	}
	public static void printArray(double[] array){
		int i;
		for(i=0;i<array.length;i++){
			System.out.println(array[i]);
			}
		}
	}

