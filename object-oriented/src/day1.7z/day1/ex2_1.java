package day1;

public class ex2_1 {
	public static void main(String[] args){
		for(int i=3;i<100;i++){
		if(i%3==1 && i%7==5 && i%5==0){
			System.out.println("���Ŵ��ı�����"+i);
	}
		}
	}
}
