package day1;

public class Test2 {
	public static void main(String[] args){
		int n=10;
		System.out.println(Mymath.getSum(n));
	}
}
