package day1;

public class TestClass {
	public static void main(String[] args){
		int testScore=50;
		System.out.println(Demon1.getGrade(testScore));
	}
}
